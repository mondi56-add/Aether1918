
# Aether 1918 - Android

1. این پوشه رو تو Android Studio باز کن
2. فایل باینری aether (برای arm64) رو بذار تو app/src/main/assets/
3. Run بزن، APK میسازه

کد MainActivity طوری نوشته که:
- دکمه START = ./aether --socks-addr 127.0.0.1:1918
- Check IP = curl --socks5 127.0.0.1:1918 https://ipinfo.io
- رمز 1918 داخل لاگ هک شده تا بفهمی خودتی

برای ساخت APK بدون Android Studio:
gradlew assembleDebug
خروجی: app/build/outputs/apk/debug/app-debug.apk
