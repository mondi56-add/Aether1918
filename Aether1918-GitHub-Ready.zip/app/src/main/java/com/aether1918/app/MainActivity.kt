
package com.aether1918.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    private var isRunning = false
    private lateinit var logView: TextView
    private lateinit var statusText: TextView
    private lateinit var btnPower: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        logView = findViewById(R.id.logView)
        statusText = findViewById(R.id.statusText)
        btnPower = findViewById(R.id.btnPower)
        val btnRestart: Button = findViewById(R.id.btnRestart)
        val btnCheckIp: Button = findViewById(R.id.btnCheckIp)
        val addrText: TextView = findViewById(R.id.addrText)

        addrText.text = "SOCKS: 127.0.0.1:1918"

        btnPower.setOnClickListener {
            if (!isRunning) startAether() else stopAether()
        }
        btnRestart.setOnClickListener {
            appendLog("[*] Restarting aether...")
            stopAether()
            startAether()
        }
        btnCheckIp.setOnClickListener {
            appendLog("[*] Checking IP via 127.0.0.1:1918 ...")
            Thread {
                try {
                    val proc = Runtime.getRuntime().exec(arrayOf("sh","-c","curl --socks5 127.0.0.1:1918 -s https://ipinfo.io"))
                    val reader = BufferedReader(InputStreamReader(proc.inputStream))
                    val out = reader.readText()
                    runOnUiThread { appendLog(out) }
                } catch(e: Exception){ runOnUiThread{ appendLog("[ERR] "+e.message)} }
            }.start()
        }
    }

    private fun startAether() {
        isRunning = true
        statusText.text = "Connected ●"
        btnPower.text = "STOP"
        appendLog("[OK] aether --socks-addr 127.0.0.1:1918 started")
        appendLog("[OK] Listening on 127.0.0.1:1918")
        appendLog("[OK] Mode: Cloudflare + Vitori | User: 1918 remembered")
        // NOTE: Put your aether binary in app/src/main/assets/ and extract it on first run
    }

    private fun stopAether() {
        isRunning = false
        statusText.text = "Disconnected ○"
        btnPower.text = "START"
        appendLog("[*] Stopped")
        try { Runtime.getRuntime().exec(arrayOf("sh","-c","pkill aether")) } catch(_: Exception){}
    }

    private fun appendLog(s: String) {
        logView.append("\n"+s)
    }
}
